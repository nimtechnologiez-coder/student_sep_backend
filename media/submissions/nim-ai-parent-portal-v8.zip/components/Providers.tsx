"use client";
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { notifications as seed, type Note } from "@/lib/data";

type Theme = "light" | "dark";
type Ctx = { theme: Theme; toggleTheme: () => void; setTheme: (t: Theme) => void; toast: (m: string) => void; notes: Note[]; markRead: (id: number) => void; markAll: () => void };
const AppCtx = createContext<Ctx>({ theme: "light", toggleTheme: () => {}, setTheme: () => {}, toast: () => {}, notes: [], markRead: () => {}, markAll: () => {} });
export const useApp = () => useContext(AppCtx);

export default function Providers({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>("light");
  const [toasts, setToasts] = useState<{ id: number; msg: string }[]>([]);
  const [notes, setNotes] = useState<Note[]>(seed);

  useEffect(() => { const t = document.documentElement.dataset.theme as Theme | undefined; if (t) setThemeState(t); }, []);
  const setTheme = useCallback((t: Theme) => { setThemeState(t); document.documentElement.dataset.theme = t; try { localStorage.setItem("pp-theme", t); } catch {} }, []);
  const toggleTheme = useCallback(() => setTheme(theme === "light" ? "dark" : "light"), [theme, setTheme]);
  const toast = useCallback((msg: string) => {
    const id = Date.now() + Math.random();
    setToasts((l) => [...l, { id, msg }]);
    setTimeout(() => setToasts((l) => l.filter((x) => x.id !== id)), 2800);
  }, []);
  const markRead = useCallback((id: number) => setNotes((l) => l.map((n) => (n.id === id ? { ...n, unread: false } : n))), []);
  const markAll = useCallback(() => setNotes((l) => l.map((n) => ({ ...n, unread: false }))), []);

  return (
    <AppCtx.Provider value={{ theme, toggleTheme, setTheme, toast, notes, markRead, markAll }}>
      {children}
      <div className="pp-toast-wrap">{toasts.map((t) => <div key={t.id} className="pp-toast">{t.msg}</div>)}</div>
    </AppCtx.Provider>
  );
}
