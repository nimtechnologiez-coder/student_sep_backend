"use client";
import { useEffect, useState, type ReactNode } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, BookOpen, Video, CalendarCheck, ClipboardList, Briefcase, CreditCard, Bell, Settings, LogOut, Menu, Moon, Sun, Search } from "lucide-react";
import { useApp } from "./Providers";
import { initials } from "./ui";
import { parent, student } from "@/lib/data";

const groups = [
  { label: "", items: [{ href: "/dashboard", name: "Dashboard", icon: LayoutDashboard }] },
  { label: "CHILD'S LEARNING", items: [
    { href: "/syllabus", name: "Syllabus", icon: BookOpen },
    { href: "/classes", name: "Classes", icon: Video },
    { href: "/attendance", name: "Attendance", icon: CalendarCheck },
    { href: "/tasks", name: "Tasks", icon: ClipboardList } ] },
  { label: "CAREER", items: [{ href: "/placement", name: "Career & Placement", icon: Briefcase }] },
  { label: "FINANCE & ALERTS", items: [
    { href: "/fees", name: "Fees & Payments", icon: CreditCard },
    { href: "/notifications", name: "Notifications", icon: Bell } ] },
  { label: "ACCOUNT", items: [{ href: "/settings", name: "Settings", icon: Settings }] },
];
const flat = groups.flatMap((g) => g.items);

export default function AppShell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const { theme, toggleTheme, toast, notes, markRead, markAll } = useApp();
  const [open, setOpen] = useState(false);
  const [drop, setDrop] = useState<"" | "bell" | "user">("");
  const [q, setQ] = useState("");

  useEffect(() => { setOpen(false); setDrop(""); }, [path]);
  if (path === "/login") return <>{children}</>;

  const unread = notes.filter((n) => n.unread).length;
  const logout = () => { toast("Logged out successfully"); router.push("/login"); };
  const search = () => {
    const hit = flat.find((i) => i.name.toLowerCase().includes(q.trim().toLowerCase()));
    if (hit && q.trim()) { router.push(hit.href); setQ(""); } else toast("No matching page found");
  };

  return (
    <div className="pp-shell">
      {open && <div className="pp-overlay" onClick={() => setOpen(false)} />}
      <aside className={`pp-side ${open ? "pp-side-open" : ""}`}>
        <div className="pp-brand"><div className="pp-logo">N</div><div><p className="pp-brand-name">NIM AI</p><p className="pp-brand-sub">PARENT PORTAL</p></div></div>
        <nav className="pp-nav">
          {groups.map((g, gi) => (
            <div key={gi}>
              {g.label && <p className="pp-nav-label">{g.label}</p>}
              {g.items.map(({ href, name, icon: Icon }) => (
                <Link key={href} href={href} className={`pp-nav-link ${path === href ? "pp-nav-link-active" : ""}`}><Icon size={18} />{name}</Link>
              ))}
            </div>
          ))}
        </nav>
        <div className="pp-side-promo"><b>Track. Support. Succeed.</b><span>Your child's progress, in one place.</span></div>
        <div className="pp-side-user">
          <div className="pp-avatar">{initials(parent.name)}</div>
          <div className="pp-side-user-info"><b>{parent.name}</b><span>{parent.relation} of {student.name.split(" ")[0]}</span></div>
          <button className="pp-icon-btn" onClick={logout} aria-label="Logout" title="Logout"><LogOut size={16} /></button>
        </div>
      </aside>

      <div className="pp-main">
        <header className="pp-top">
          <button className="pp-icon-btn pp-menu-btn" onClick={() => setOpen(true)} aria-label="Open menu"><Menu size={18} /></button>
          <div className="pp-search"><Search size={16} /><input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && search()} placeholder="Search pages: fees, syllabus…" /></div>
          <div className="pp-top-right">
            <button className="pp-icon-btn" onClick={toggleTheme} aria-label="Toggle theme" title="Toggle theme">{theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}</button>
            <div className="pp-drop-wrap">
              <button className="pp-icon-btn" onClick={() => setDrop(drop === "bell" ? "" : "bell")} aria-label="Notifications"><Bell size={18} />{unread > 0 && <span className="pp-dot">{unread}</span>}</button>
              {drop === "bell" && (
                <div className="pp-drop">
                  <div className="pp-drop-head"><span>Notifications</span><button className="pp-link" onClick={markAll}>Mark all read</button></div>
                  {notes.slice(0, 5).map((n) => (
                    <button key={n.id} className={`pp-drop-item ${n.unread ? "pp-drop-unread" : ""}`} onClick={() => { markRead(n.id); router.push("/notifications"); }}>
                      <div><b>{n.title}</b><small>{n.body}</small></div>
                    </button>
                  ))}
                  <button className="pp-btn pp-btn-sm pp-btn-block" style={{ marginTop: 6 }} onClick={() => router.push("/notifications")}>View all notifications</button>
                </div>
              )}
            </div>
            <div className="pp-drop-wrap">
              <button className="pp-user-btn" onClick={() => setDrop(drop === "user" ? "" : "user")}>
                <div className="pp-avatar">{initials(parent.name)}</div>
                <div className="pp-user-text"><b>{parent.name}</b><span>Parent of {student.name.split(" ")[0]}</span></div>
              </button>
              {drop === "user" && (
                <div className="pp-drop" style={{ width: 220 }}>
                  <button className="pp-drop-item" onClick={() => router.push("/settings")}><Settings size={16} />Settings</button>
                  <button className="pp-drop-item pp-drop-danger" onClick={logout}><LogOut size={16} />Logout</button>
                </div>
              )}
            </div>
          </div>
        </header>
        <main className="pp-content" onClick={() => drop && setDrop("")}>{children}</main>
      </div>
    </div>
  );
}
