"use client";
import type { ReactNode } from "react";
import { X } from "lucide-react";
import { student } from "@/lib/data";

export function PageHead({ title, sub, icon, children }: { title: string; sub: string; icon?: ReactNode; children?: ReactNode }) {
  return (
    <div className="pp-banner">
      <div className="pp-banner-main">
        {icon && <div className="pp-banner-icon">{icon}</div>}
        <div>
          <p className="pp-banner-crumb">NIM AI • Parent Portal</p>
          <h1>{title}</h1>
          <p className="pp-banner-sub">{sub}</p>
          <div className="pp-banner-chips"><span>{student.name}</span><span>{student.batch.split(" • ")[0]}</span><span>Month {student.month} • Week {student.week}</span></div>
        </div>
      </div>
      {children && <div className="pp-banner-actions">{children}</div>}
    </div>
  );
}
export function Card({ title, sub, action, children, className = "" }: { title?: string; sub?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`pp-card ${className}`}>
      {title && <div className="pp-card-head"><div><h2 className="pp-card-title">{title}</h2>{sub && <p className="pp-card-sub">{sub}</p>}</div>{action}</div>}
      {children}
    </section>
  );
}
export function Badge({ tone = "gray", children }: { tone?: "blue" | "green" | "amber" | "red" | "gray"; children: ReactNode }) {
  return <span className={`pp-badge pp-tone-${tone}`}>{children}</span>;
}
export function Progress({ value, color = "" }: { value: number; color?: "" | "pp-bar-green" | "pp-bar-amber" }) {
  return <div className="pp-progress"><div className={`pp-progress-bar ${color}`} style={{ width: `${Math.min(100, value)}%` }} /></div>;
}
export function Stat({ label, value, sub, tone, icon }: { label: string; value: string; sub?: string; tone: "blue" | "green" | "amber" | "red"; icon: ReactNode; progress?: number }) {
  return (
    <div className={`pp-card pp-stat2 pp-stat2-${tone}`}>
      <div className="pp-stat2-icon">{icon}</div>
      <div className="pp-stat2-body">
        <p className="pp-stat2-label">{label}</p>
        <p className="pp-stat2-val">{value}</p>
        {sub && <p className="pp-stat2-sub">{sub}</p>}
      </div>
    </div>
  );
}
export function Tabs<T extends string>({ items, value, onChange }: { items: T[]; value: T; onChange: (v: T) => void }) {
  return <div className="pp-tabs">{items.map((i) => <button key={i} className={`pp-tab ${i === value ? "pp-tab-on" : ""}`} onClick={() => onChange(i)}>{i}</button>)}</div>;
}
export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="pp-modal-back" onClick={onClose}>
      <div className="pp-modal" onClick={(e) => e.stopPropagation()}>
        <div className="pp-modal-head"><span>{title}</span><button className="pp-icon-btn" onClick={onClose} aria-label="Close"><X size={16} /></button></div>
        {children}
      </div>
    </div>
  );
}
export function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return <button role="switch" aria-checked={on} className={`pp-toggle ${on ? "pp-toggle-on" : ""}`} onClick={() => onChange(!on)} />;
}
export const initials = (n: string) => n.split(" ").map((w) => w[0]).join("").slice(0, 2);
