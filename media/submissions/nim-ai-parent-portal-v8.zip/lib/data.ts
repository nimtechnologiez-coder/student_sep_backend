export const parent = { name: "Rajesh Kumar", relation: "Father" };
export const student = { name: "Arjun Kumar", id: "NIM-AI-2026-0142", program: "Generative AI Engineering Program", batch: "AI Cohort 2026 • Morning Batch", mentor: "Priya Sharma", month: 4, week: 15, progress: 72 };

export type Inst = { name: string; amount: number; due: string; status: "Paid" | "Due Soon" | "Upcoming"; invoice: string };
export const fees = { total: 120000, installments: [
  { name: "Installment 1 (Enrollment)", amount: 40000, due: "01 Jun 2026", status: "Paid", invoice: "NIM-INV-2026-0812" },
  { name: "Installment 2 (Mid-Term)", amount: 40000, due: "01 Aug 2026", status: "Paid", invoice: "NIM-INV-2026-1142" },
  { name: "Installment 3 (Advanced AI)", amount: 20000, due: "15 Oct 2026", status: "Due Soon", invoice: "-" },
  { name: "Installment 4 (Placement Gateway)", amount: 20000, due: "15 Dec 2026", status: "Upcoming", invoice: "-" },
] as Inst[] };
export const paymentMethods = [
  { id: "upi", name: "UPI", hint: "GPay, PhonePe, Paytm, BHIM" },
  { id: "card", name: "Credit / Debit Card", hint: "Visa, Mastercard, RuPay" },
  { id: "netbanking", name: "Net Banking", hint: "All major Indian banks" },
  { id: "emi", name: "No-cost EMI", hint: "3 or 6 month EMI on select cards" },
  { id: "bank", name: "Bank Transfer", hint: "NEFT / IMPS with UTR number" },
];

export type Month = { m: number; title: string; status: string; pct: number; weeks: string; goal: string; topics: { k: string; v: string }[]; lab: string; gateway?: string };
export const months: Month[] = [
  { m: 1, title: "Python & Math Foundations", status: "Completed", pct: 100, weeks: "Weeks 1–4", goal: "Master the math and programming required for AI systems.", topics: [{ k: "Python for AI", v: "Data structures, OOP, modular engineering" }, { k: "Applied linear algebra", v: "Vectors, matrices, eigenvectors" }, { k: "Calculus & statistics", v: "Gradients, Bayes' theorem, hypothesis testing" }, { k: "Data handling", v: "APIs, JSON" }], lab: "Financial / Healthcare Data EDA & Statistical Report" },
  { m: 2, title: "Machine Learning", status: "Completed", pct: 100, weeks: "Weeks 5–8", goal: "Master classical supervised & unsupervised ML algorithms and metrics.", topics: [{ k: "Supervised", v: "Linear/Logistic Regression, Decision Trees" }, { k: "Gradient boosting", v: "XGBoost, LightGBM, CatBoost" }, { k: "Unsupervised & tuning", v: "K-Means, DBSCAN, PCA, ROC-AUC, SMOTE" }], lab: "End-to-End Customer Churn Analytics Pipeline", gateway: "Gateway 1 Evaluation" },
  { m: 3, title: "Deep Learning & Computer Vision", status: "Completed", pct: 100, weeks: "Weeks 9–12", goal: "Understand neural-network mechanics, backpropagation and visual data pipelines.", topics: [{ k: "ANN architectures", v: "Perceptrons, MLPs, ReLU, Softmax" }, { k: "Optimization", v: "Adam, SGD, RMSProp, regularization & dropout" }, { k: "CNNs", v: "Convolutions, pooling, feature-map visualization" }, { k: "Vision frameworks", v: "ResNet, transfer learning (PyTorch), YOLO, OpenCV" }], lab: "Real-Time Multi-Class Object Detection System" },
  { m: 4, title: "NLP & Transformers", status: "In Progress", pct: 68, weeks: "Weeks 13–16", goal: "Move from recurrent networks to modern Transformers.", topics: [{ k: "Classical NLP", v: "Tokenization, TF-IDF, Word2Vec, GloVe" }, { k: "Sequence models", v: "RNN, LSTM, GRU" }, { k: "Transformers", v: "Self-attention, BERT, RoBERTa, GPT" }], lab: "Fine-Tuning BERT for Sentiment & NER", gateway: "Gateway 2 Evaluation" },
  { m: 5, title: "Generative AI & RAG", status: "Upcoming", pct: 0, weeks: "Weeks 17–20", goal: "Master LLMs, prompt engineering and RAG architectures.", topics: [{ k: "Foundations", v: "Llama, Mistral, GPT-4, quantization" }, { k: "Vector DBs", v: "ChromaDB, Pinecone, FAISS, Qdrant" }, { k: "Orchestration", v: "LangChain, LlamaIndex, hybrid search, reranking" }], lab: "Enterprise Hybrid RAG Q&A Chatbot" },
  { m: 6, title: "Agentic AI & Capstone", status: "Upcoming", pct: 0, weeks: "Weeks 21–24", goal: "Build multi-agent systems, fine-tune models and deploy.", topics: [{ k: "Agents", v: "LangGraph, CrewAI, tool calling, memory" }, { k: "Fine-tuning", v: "PEFT, LoRA, QLoRA, DPO/RLHF" }, { k: "Production", v: "FastAPI, Docker, Streamlit, AWS" }], lab: "Autonomous Market Analyst on AWS", gateway: "Gateway 3 — Industry Capstone" },
];
export const stack = [
  { t: "Python & Data Science", v: "NumPy, Pandas, Scikit-Learn, XGBoost, LightGBM" },
  { t: "Deep Learning & CV", v: "PyTorch, TensorFlow, OpenCV, HuggingFace" },
  { t: "GenAI & Vector DBs", v: "LangChain, LlamaIndex, ChromaDB, FAISS, Ollama" },
  { t: "Agents & MLOps", v: "LangGraph, CrewAI, FastAPI, Docker, AWS" },
];
export const highlights = [
  { t: "End-to-End Curriculum", v: "Python foundations through advanced LangGraph multi-agent, GenAI & RAG pipelines." },
  { t: "Production & MLOps Focus", v: "Build microservices with FastAPI, containerize with Docker and deploy to the cloud." },
  { t: "GenAI & Agentic Systems", v: "LLM fine-tuning (LoRA/QLoRA), RAG architectures, vector databases and AI agents." },
  { t: "Career & Placement Layer", v: "Resume, LinkedIn, GitHub portfolio, mock interviews, internship and placement support." },
];

export type Session = { day: number; topic: string; time: string; trainer: string; status: "present" | "absent" | "late" | "scheduled"; note: string };
const T = "10:00 AM – 1:00 PM";
export const sessions: Session[] = [
  { day: 1, topic: "Text Normalization & Tokenizers", time: T, trainer: "Priya Sharma", status: "present", note: "Attended full session" },
  { day: 2, topic: "TF-IDF & Vector Space Models", time: T, trainer: "Karthik R", status: "present", note: "Attended full session" },
  { day: 4, topic: "Classical NLP Lab: Tokenization Pipeline", time: T, trainer: "Priya Sharma", status: "present", note: "Lab submitted on time" },
  { day: 9, topic: "Word2Vec & GloVe Embeddings", time: T, trainer: "Karthik R", status: "present", note: "Attended full session" },
  { day: 11, topic: "Embeddings Lab: Semantic Search", time: T, trainer: "Priya Sharma", status: "present", note: "Lab submitted on time" },
  { day: 15, topic: "RNN Fundamentals", time: T, trainer: "Priya Sharma", status: "present", note: "Attended full session" },
  { day: 16, topic: "LSTM & GRU Networks", time: T, trainer: "Karthik R", status: "present", note: "Attended full session" },
  { day: 17, topic: "Sequence Models Lab (RNN, LSTM, GRU)", time: T, trainer: "Priya Sharma", status: "absent", note: "Unexcused absence. Recording and lab notes available on request." },
  { day: 18, topic: "Sequence Models Lab: Recap", time: T, trainer: "Karthik R", status: "late", note: "Joined 25 minutes late." },
  { day: 22, topic: "Attention Mechanism Basics", time: T, trainer: "Priya Sharma", status: "present", note: "Attended full session" },
  { day: 23, topic: "Self-Attention & Multi-Head Projections", time: T, trainer: "Priya Sharma", status: "present", note: "Attended full session" },
  { day: 24, topic: "Transformers: BERT Architecture", time: T, trainer: "Priya Sharma", status: "scheduled", note: "Today's live class. Attendance is marked automatically." },
  { day: 25, topic: "RoBERTa & GPT Overview", time: T, trainer: "Karthik R", status: "scheduled", note: "Live class" },
  { day: 29, topic: "Lab: Fine-Tuning BERT for Sentiment & NER", time: T, trainer: "Priya Sharma", status: "scheduled", note: "Hands-on lab session" },
  { day: 30, topic: "Gateway 2 Revision & Doubt Session", time: T, trainer: "Priya Sharma", status: "scheduled", note: "Revision before Gateway 2" },
];
const WD = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
export const dayLabel = (d: number) => `${WD[new Date(2026, 8, d).getDay()]}, ${String(d).padStart(2, "0")} Sep 2026`;
export const weekday = (d: number) => WD[new Date(2026, 8, d).getDay()];

export const attendance = { total: 48, present: 43, late: 2, absent: 3, minimum: 85, trend: [30, 50, 68, 68, 85, 80, 88, 92],
  record: [{ date: "18 Sep 2026", topic: "Sequence Models Lab: Recap", tag: "Late (25 min)", tone: "amber" }, { date: "17 Sep 2026", topic: "Sequence Models Lab (RNN, LSTM, GRU)", tag: "Unexcused", tone: "red" }, { date: "21 Aug 2026", topic: "CNN Transfer Learning Lab", tag: "Unexcused", tone: "red" }, { date: "06 Aug 2026", topic: "Object Detection with YOLO", tag: "Excused (Medical)", tone: "amber" }] as { date: string; topic: string; tag: string; tone: "red" | "amber" }[] };

export type Task = { id: number; name: string; type: "Lab" | "Assignment" | "Test" | "Career"; month: number; due: string; status: "Pending" | "Submitted" | "Upcoming"; desc: string };
export const tasks: Task[] = [
  { id: 1, name: "Lab: Fine-Tuning BERT for Sentiment & NER", type: "Lab", month: 4, due: "26 Sep 2026", status: "Pending", desc: "Fine-tune a BERT model with HuggingFace and report sentiment and NER results." },
  { id: 2, name: "Self-Attention Implementation in PyTorch", type: "Assignment", month: 4, due: "29 Sep 2026", status: "Pending", desc: "Implement scaled dot-product and multi-head attention from scratch." },
  { id: 3, name: "Portfolio Website (GitHub Pages)", type: "Career", month: 4, due: "05 Oct 2026", status: "Pending", desc: "Publish projects with README, demos and live links." },
  { id: 4, name: "Gateway 2 Revision Test", type: "Test", month: 4, due: "10 Oct 2026", status: "Upcoming", desc: "Timed practice test covering Deep Learning, NLP and Transformers." },
  { id: 5, name: "LSTM & GRU Sequence Models Assignment", type: "Assignment", month: 4, due: "12 Sep 2026", status: "Submitted", desc: "Compare RNN, LSTM and GRU on a text classification dataset." },
  { id: 6, name: "Word2Vec & GloVe Embeddings Notebook", type: "Assignment", month: 4, due: "05 Sep 2026", status: "Submitted", desc: "Train and visualize embeddings, then run a similarity search." },
  { id: 7, name: "Lab: Real-Time Multi-Class Object Detection", type: "Lab", month: 3, due: "28 Aug 2026", status: "Submitted", desc: "Build a YOLO based real-time detection system with OpenCV." },
  { id: 8, name: "Resume & LinkedIn Review", type: "Career", month: 3, due: "20 Aug 2026", status: "Submitted", desc: "Role-based resume and LinkedIn profile approved by mentors." },
  { id: 9, name: "Lab: Customer Churn Analytics Pipeline", type: "Lab", month: 2, due: "10 Jul 2026", status: "Submitted", desc: "End-to-end ML pipeline with XGBoost, ROC-AUC and SMOTE." },
  { id: 10, name: "Lab: Financial / Healthcare Data EDA", type: "Lab", month: 1, due: "20 Jun 2026", status: "Submitted", desc: "Exploratory data analysis and statistical report." },
];

export const gateways = [
  { n: 1, title: "Gateway 1 — After Month 2", focus: "Foundation", covers: "Python, statistics & ML fundamentals, problem solving, baseline checkpoint.", status: "Cleared", note: "Scored 88% (Top 10%)" },
  { n: 2, title: "Gateway 2 — After Month 4", focus: "AI Engineering", covers: "Deep Learning, NLP, Transformers, project implementation, skill-gap report.", status: "Upcoming", note: "15 Oct 2026 • MCQs + 90 min live PyTorch challenge" },
  { n: 3, title: "Gateway 3 — Final Phase", focus: "Industry Capstone", covers: "Production-grade capstone, technical viva, presentation, job-readiness report.", status: "Upcoming", note: "After Month 6" },
];
export const career = { role: "AI / Generative AI Engineer", ready: 82,
  items: [{ n: "Resume / CV", v: "Approved (90%)", ok: true }, { n: "LinkedIn Profile", v: "Optimized", ok: true }, { n: "GitHub Repository", v: "14 repos", ok: true }, { n: "Portfolio Website", v: "70% in progress", ok: false }],
  journey: [{ m: "MONTH 3", t: "Placement Track Begins", v: "Resume drafting, LinkedIn setup and GitHub portfolio started alongside your first major project.", s: "done" }, { m: "MONTH 4", t: "Skill Building", v: "Communication training, aptitude practice and first technical mock interviews.", s: "now" }, { m: "MONTH 5", t: "Portfolio & Projects", v: "GenAI / RAG projects deployed with README, demos and live links; role mapping begins.", s: "" }, { m: "MONTH 6", t: "Interview Ready", v: "Capstone, Gateway 3 job-readiness report, final resume and company-specific interview prep.", s: "" }, { m: "AFTER", t: "Interviews & Offers", v: "Employer pipeline, interview scheduling, feedback loop and offer / joining support.", s: "" }],
  requirements: [{ t: "Attendance and assignment discipline maintained", ok: true }, { t: "All three Gateway evaluations completed", ok: false }, { t: "Capstone project and GitHub portfolio finalized", ok: false }, { t: "Resume and LinkedIn reviewed and approved by mentors", ok: true }, { t: "Mock interview (technical + HR) completed with feedback", ok: false }, { t: "Placement readiness review cleared by academic team", ok: false }],
  support: [{ t: "Resume Preparation", v: "Role-based resume with measurable project achievements.", s: "Approved (90%)" }, { t: "LinkedIn Profile", v: "Headline, About section and project showcase.", s: "Optimized" }, { t: "GitHub & Portfolio", v: "Repo structure, README, demos and deployment links.", s: "14 repos • portfolio 70%" }, { t: "Communication Training", v: "Self-introduction, project explanation and presentation skills.", s: "In progress (Month 4)" }, { t: "Technical & Mock Interviews", v: "AI/ML/GenAI fundamentals, coding, project deep-dives and HR rounds.", s: "First mock in Month 4" }, { t: "Placement Assistance", v: "Role mapping, employer pipeline and structured interview support.", s: "Opens after requirements" }],
  companies: ["Global Quest", "Strategy", "A&T", "Hire 3X", "Wyreflow", "Cloud Build Technology", "Techno Logics", "MeetMux", "Face Prep", "Zencrop Techno Solution", "iQIGAI.AI", "Soft Suave", "Hexaware", "ITC Infotech", "Resnet Solution", "Smart DV", "Nucor", "NIM Technologies"] };

export type Note = { id: number; type: "Fees" | "Academic" | "Events"; title: string; body: string; time: string; unread: boolean };
export const notifications: Note[] = [
  { id: 1, type: "Fees", title: "Fee due soon", body: "Installment 3 of ₹20,000 is due on 15 Oct 2026. Pay online to keep the account in good standing.", time: "Today, 9:00 AM", unread: true },
  { id: 2, type: "Academic", title: "Absent on 17 Sep", body: "Arjun missed the Sequence Models Lab (RNN, LSTM, GRU).", time: "17 Sep 2026", unread: true },
  { id: 3, type: "Academic", title: "Late arrival on 18 Sep", body: "Arjun joined the Sequence Models recap 25 minutes late.", time: "18 Sep 2026", unread: true },
  { id: 4, type: "Events", title: "Masterclass: Production RAG", body: "Guest session with a Google Cloud lead on 27 Sep at 4:00 PM.", time: "22 Sep 2026", unread: false },
  { id: 5, type: "Events", title: "Gateway 2 Evaluation announced", body: "15 Oct 2026: MCQs and a 90-minute live PyTorch challenge.", time: "20 Sep 2026", unread: false },
  { id: 6, type: "Academic", title: "New task assigned", body: "Lab: Fine-Tuning BERT for Sentiment & NER, due 26 Sep 2026.", time: "19 Sep 2026", unread: false },
  { id: 7, type: "Academic", title: "Monthly progress report ready", body: "August report generated from attendance, assignments, project progress and mentor feedback.", time: "01 Sep 2026", unread: false },
  { id: 8, type: "Events", title: "Parent progress review", body: "Online monthly progress review on 03 Oct 2026, 5:00 PM.", time: "18 Sep 2026", unread: false },
];
export const inr = (n: number) => "₹" + n.toLocaleString("en-IN");
export const download = (name: string, text: string) => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text], { type: "text/plain" })); a.download = name; a.click(); };
