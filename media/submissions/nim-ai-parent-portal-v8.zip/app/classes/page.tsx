"use client";
import { useState } from "react";
import { Video, CheckCircle2, XCircle, Percent, Clock, User, MonitorPlay } from "lucide-react";
import { Card, PageHead, Stat, Badge, Tabs, Modal } from "@/components/ui";
import { useApp } from "@/components/Providers";
import { sessions, dayLabel, weekday, type Session } from "@/lib/data";

const label = (s: Session) => (s.status === "scheduled" ? "Upcoming" : s.status === "absent" ? "Missed" : "Completed");
const tone = (s: Session) => (s.status === "scheduled" ? "blue" : s.status === "absent" ? "red" : s.status === "late" ? "amber" : "green") as "blue" | "red" | "amber" | "green";
const MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep"];
const monday = (d: number) => d - ((new Date(2026, 8, d).getDay() + 6) % 7);
const weekName = (m: number) => { const dt = new Date(2026, 8, m); const base = `${dt.getDate()} ${MON[dt.getMonth()]}`; return m === 21 ? `THIS WEEK • FROM ${base.toUpperCase()}` : `WEEK OF ${base.toUpperCase()}`; };

export default function Classes() {
  const { toast } = useApp();
  const [tab, setTab] = useState("All");
  const [sel, setSel] = useState<Session | null>(null);
  const count = (l: string) => sessions.filter((s) => label(s) === l).length;
  const done = count("Completed"), missed = count("Missed"), up = count("Upcoming");
  const held = sessions.filter((s) => s.status !== "scheduled").length;
  const list = sessions.filter((s) => tab === "All" || label(s) === tab);
  const weeks = Array.from(new Set(list.map((s) => monday(s.day)))).sort((a, b) => b - a);
  const trainers = Array.from(new Set(sessions.map((s) => s.trainer)));
  const d1 = (done / sessions.length) * 360, d2 = d1 + (missed / sessions.length) * 360;
  return (
    <>
      <PageHead icon={<Video size={26} />} title="Classes" sub="Live class schedule of your child: this week's sessions, completed classes and missed classes." />
      <div className="pp-grid pp-g4 pp-keep2">
        <Stat label="Upcoming" progress={(up / sessions.length) * 100} value={String(up)} sub="Scheduled this month" tone="blue" icon={<Video size={20} />} />
        <Stat label="Completed" progress={(done / sessions.length) * 100} value={String(done)} sub="Attended in September" tone="green" icon={<CheckCircle2 size={20} />} />
        <Stat label="Missed" progress={(missed / sessions.length) * 100} value={String(missed)} sub="Recording on request" tone="red" icon={<XCircle size={20} />} />
        <Stat label="September attendance" progress={(done / held) * 100} value={`${Math.round((done / held) * 100)}%`} sub="Present + late" tone="amber" icon={<Percent size={20} />} />
      </div>
      <div className="pp-grid pp-g3">
        <Card title="Month overview" sub="September 2026">
          <div className="pp-flex pp-fill">
            <div className="pp-donut" style={{ background: `conic-gradient(var(--pp-green) 0 ${d1}deg,var(--pp-red) ${d1}deg ${d2}deg,var(--pp-pri) ${d2}deg 360deg)`, width: 110, height: 110 }}><div className="pp-donut-in" style={{ width: 76, height: 76, fontSize: 17 }}><div>{sessions.length}<small>classes</small></div></div></div>
            <div className="pp-legend"><div><span>Completed</span><b>{done}</b></div><div><span>Missed</span><b>{missed}</b></div><div><span>Upcoming</span><b>{up}</b></div></div>
          </div>
        </Card>
        <Card title="Trainers"><div className="pp-list pp-fill">{trainers.map((t) => (
          <div key={t} className="pp-item"><div className="pp-row-start"><div className="pp-avatar">{t.split(" ").map((w) => w[0]).join("")}</div><div className="pp-item-main"><p className="pp-item-title">{t}</p><p className="pp-item-sub">{sessions.filter((s) => s.trainer === t).length} sessions this month</p></div></div></div>
        ))}</div></Card>
        <Card title="Schedule info" action={<Clock size={18} color="var(--pp-pri)" />}>
          <div className="pp-list pp-fill">
            <div className="pp-item"><span className="pp-item-sub">Timing</span><b>10:00 AM – 1:00 PM</b></div>
            <div className="pp-item"><span className="pp-item-sub">Mode</span><b>Live online (Google Meet)</b></div>
            <div className="pp-item"><span className="pp-item-sub">Batch</span><b>AI Cohort 2026 • Morning</b></div>
          </div>
        </Card>
      </div>
      <Tabs items={["All", "Upcoming", "Completed", "Missed"]} value={tab} onChange={setTab} />
      {weeks.map((w) => (
        <div key={w} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <p className="pp-week pp-card-sub" style={{ fontWeight: 600, letterSpacing: ".06em" }}>{weekName(w)}</p>
          <div className="pp-cls-grid">{list.filter((s) => monday(s.day) === w).map((s) => (
            <div key={s.day} className={`pp-sess pp-sess-${s.status}`}>
              <div className="pp-sess-date"><b>{s.day}</b><span>{weekday(s.day)}</span><small>SEP</small></div>
              <div className="pp-sess-body">
                <div className="pp-sess-top"><Badge tone={tone(s)}>{s.status === "late" ? "Late" : label(s)}</Badge><span className="pp-item-sub">Session {sessions.indexOf(s) + 1} of {sessions.length}</span></div>
                <h3 className="pp-sess-title">{s.topic}</h3>
                <div className="pp-sess-meta"><span><Clock size={14} />{s.time}</span><span><User size={14} />{s.trainer}</span><span><MonitorPlay size={14} />Live online</span></div>
                <div className="pp-sess-note">{s.note}</div>
                <div className="pp-sess-actions"><button className="pp-btn pp-btn-sm" onClick={() => setSel(s)}>View details</button>{s.status === "absent" && <button className="pp-btn pp-btn-sm pp-btn-primary" onClick={() => toast("Recording request sent to the academy")}>Ask recording</button>}{s.status === "scheduled" && <button className="pp-btn pp-btn-sm pp-btn-primary" onClick={() => toast("Reminder set for the student")}>Remind child</button>}</div>
              </div>
            </div>
          ))}</div>
        </div>
      ))}
      {list.length === 0 && <Card><p className="pp-empty">No classes in this list.</p></Card>}
      {sel && (
        <Modal title={sel.topic} onClose={() => setSel(null)}>
          <div className="pp-kv" style={{ marginBottom: 14 }}>
            <div><small>Date</small><b>{dayLabel(sel.day)}</b></div><div><small>Time</small><b>{sel.time}</b></div>
            <div><small>Trainer</small><b>{sel.trainer}</b></div><div><small>Mode</small><b>Live online (Google Meet)</b></div>
            <div><small>Status</small><b>{label(sel)}</b></div><div><small>Note</small><b>{sel.note}</b></div>
          </div>
        </Modal>
      )}
    </>
  );
}
