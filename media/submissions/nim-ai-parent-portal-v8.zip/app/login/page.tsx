"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Moon, Sun } from "lucide-react";
import { useApp } from "@/components/Providers";

export default function Login() {
  const router = useRouter();
  const { theme, toggleTheme, toast } = useApp();
  const [phone, setPhone] = useState("");
  const [pass, setPass] = useState("");
  const submit = () => {
    if (!phone.trim() || !pass.trim()) return toast("Enter mobile number and password");
    toast("Welcome back!"); router.push("/dashboard");
  };
  return (
    <div className="pp-login">
      <div className="pp-login-card">
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
          <div className="pp-brand" style={{ padding: 0 }}><div className="pp-logo">N</div><div><p className="pp-brand-name">NIM AI</p><p className="pp-brand-sub">PARENT PORTAL</p></div></div>
          <button className="pp-icon-btn" onClick={toggleTheme} aria-label="Toggle theme">{theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}</button>
        </div>
        <h1 style={{ fontSize: 24, fontWeight: 700 }}>Parent login</h1>
        <p className="pp-card-sub" style={{ marginBottom: 18 }}>Sign in to track your child's progress and fees.</p>
        <div className="pp-field"><label>Registered mobile number</label><input className="pp-input" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="+91 98765 43210" /></div>
        <div className="pp-field"><label>Password</label><input className="pp-input" type="password" value={pass} onChange={(e) => setPass(e.target.value)} placeholder="••••••••" onKeyDown={(e) => e.key === "Enter" && submit()} /></div>
        <button className="pp-btn pp-btn-primary pp-btn-block" onClick={submit}>Sign in</button>
        <button className="pp-btn pp-btn-block" style={{ marginTop: 10 }} onClick={() => toast("OTP sent to your mobile (demo)")}>Login with OTP</button>
      </div>
    </div>
  );
}
