import "./globals.css";
import type { ReactNode } from "react";
import Providers from "@/components/Providers";
import AppShell from "@/components/AppShell";

export const metadata = { title: "NIM AI | Parent Portal", viewport: "width=device-width, initial-scale=1" };
const themeScript = `try{var t=localStorage.getItem("pp-theme")||(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");document.documentElement.dataset.theme=t}catch(e){}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body><Providers><AppShell>{children}</AppShell></Providers></body>
    </html>
  );
}
