"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { LogOut, Settings } from "lucide-react";
import { Card, PageHead, Toggle } from "@/components/ui";
import { useApp } from "@/components/Providers";
import { parent, student } from "@/lib/data";

export default function SettingsPage() {
  const router = useRouter();
  const { theme, setTheme, toast } = useApp();
  const [pw, setPw] = useState({ a: "", b: "" });
  const [lang, setLang] = useState("English");
  const [otp, setOtp] = useState(true);
  return (
    <>
      <PageHead icon={<Settings size={26} />} title="Settings" sub="Appearance, language, password and account security." />
      <div className="pp-grid pp-g2">
        <Card title="Appearance" sub="Choose how the portal looks">
          <div className="pp-flex pp-fill" style={{ alignItems: "stretch", flexWrap: "nowrap" }}>
            {(["light", "dark"] as const).map((t) => (
              <button key={t} className={`pp-theme-tile ${theme === t ? "pp-theme-tile-on" : ""}`} onClick={() => setTheme(t)}>
                <div className="pp-theme-prev" style={{ background: t === "light" ? "#f3f6fc" : "#080f20" }} />
                <b>{t === "light" ? "Light" : "Dark"}</b><p className="pp-card-sub">{theme === t ? "Active" : "Tap to switch"}</p>
              </button>
            ))}
          </div>
        </Card>
        <Card title="Change password">
          <div className="pp-field"><label>Current password</label><input className="pp-input" type="password" value={pw.a} onChange={(e) => setPw({ ...pw, a: e.target.value })} /></div>
          <div className="pp-field"><label>New password</label><input className="pp-input" type="password" value={pw.b} onChange={(e) => setPw({ ...pw, b: e.target.value })} /></div>
          <button className="pp-btn pp-btn-primary" onClick={() => { if (pw.a && pw.b.length >= 6) { toast("Password updated"); setPw({ a: "", b: "" }); } else toast("New password needs 6+ characters"); }}>Update password</button>
        </Card>
      </div>
      <div className="pp-grid pp-g2">
        <Card title="Language & reports">
          <div className="pp-field"><label>Preferred language for reports</label><select className="pp-input" value={lang} onChange={(e) => { setLang(e.target.value); toast(`Language set to ${e.target.value}`); }}>{["English", "Tamil", "Hindi", "Telugu", "Malayalam"].map((l) => <option key={l}>{l}</option>)}</select></div>
          <div className="pp-item"><div className="pp-item-main"><p className="pp-item-title">Monthly progress report by email</p><p className="pp-item-sub">Auto-generated on the 1st of every month</p></div><Toggle on={true} onChange={() => toast("Report emails stay on for parents")} /></div>
        </Card>
        <Card title="Account & security">
          <div className="pp-kv" style={{ marginBottom: 12 }}><div><small>Logged in as</small><b>{parent.name} ({parent.relation})</b></div><div><small>Linked student</small><b>{student.name}</b></div></div>
          <div className="pp-item" style={{ marginBottom: 12 }}><div className="pp-item-main"><p className="pp-item-title">OTP verification at login</p><p className="pp-item-sub">Extra security for your account</p></div><Toggle on={otp} onChange={(v) => { setOtp(v); toast(`OTP verification ${v ? "on" : "off"}`); }} /></div>
          <button className="pp-btn pp-btn-danger" onClick={() => { toast("Logged out successfully"); router.push("/login"); }}><LogOut size={16} />Logout</button>
        </Card>
      </div>
    </>
  );
}
