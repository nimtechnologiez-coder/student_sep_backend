"use client";
import { useState } from "react";
import { Wallet, CheckCircle2, AlertCircle, CalendarClock, Download, Check, CreditCard, Smartphone, Landmark, Percent, ArrowLeftRight } from "lucide-react";
import { Card, PageHead, Stat, Badge, Progress, Modal } from "@/components/ui";
import { useApp } from "@/components/Providers";
import { fees, paymentMethods, inr, download, type Inst } from "@/lib/data";

type Pay = { label: string; amount: number; names: string[] };
const tone = (s: string) => (s === "Paid" ? "green" : s === "Due Soon" ? "amber" : "gray") as "green" | "amber" | "gray";
const micon: Record<string, React.ReactNode> = { upi: <Smartphone size={18} />, card: <CreditCard size={18} />, netbanking: <Landmark size={18} />, emi: <Percent size={18} />, bank: <ArrowLeftRight size={18} /> };

export default function Fees() {
  const { toast } = useApp();
  const [list, setList] = useState<Inst[]>(fees.installments);
  const [pay, setPay] = useState<Pay | null>(null);
  const [method, setMethod] = useState("upi");
  const [busy, setBusy] = useState(false);
  const [upi, setUpi] = useState("");
  const [tenure, setTenure] = useState("3");
  const paid = list.filter((i) => i.status === "Paid").reduce((s, i) => s + i.amount, 0);
  const pending = list.filter((i) => i.status !== "Paid");
  const balance = fees.total - paid;
  const next = pending[0];
  const one = (i: Inst): Pay => ({ label: i.name, amount: i.amount, names: [i.name] });

  const confirm = () => {
    if (!pay) return;
    if (method === "upi" && !upi.includes("@")) return toast("Enter a valid UPI ID (name@bank)");
    setBusy(true);
    setTimeout(() => {
      setList((l) => l.map((i) => (pay.names.includes(i.name) ? { ...i, status: "Paid", invoice: "NIM-INV-2026-" + Math.floor(1000 + Math.random() * 9000), due: "24 Sep 2026" } : i)));
      setBusy(false); setPay(null); toast(`Payment of ${inr(pay.amount)} successful (demo)`);
    }, 1200);
  };
  const receipt = (i: Inst) => { download(`${i.invoice}.txt`, `NIM AI Career Academy\nReceipt: ${i.invoice}\n${i.name}\nAmount: ${inr(i.amount)}\nPaid on: ${i.due}`); toast("Receipt downloaded"); };

  return (
    <>
      <PageHead icon={<CreditCard size={26} />} title="Fees & Payments" sub="Installment schedule, remaining balance, receipts and secure online payment.">
        {next && <button className="pp-btn pp-btn-primary" onClick={() => setPay(one(next))}>Pay next {inr(next.amount)}</button>}
      </PageHead>
      <div className="pp-grid pp-g4">
        <Stat label="Total program fee" progress={100} value={inr(fees.total)} sub="All 6 months included" tone="blue" icon={<Wallet size={20} />} />
        <Stat label="Total paid" progress={(paid / fees.total) * 100} value={inr(paid)} sub={`${list.length - pending.length} installment(s) cleared`} tone="green" icon={<CheckCircle2 size={20} />} />
        <Stat label="Remaining to pay" progress={(balance / fees.total) * 100} value={inr(balance)} sub={`${pending.length} installment(s) pending`} tone="red" icon={<AlertCircle size={20} />} />
        <Stat label="Next due" progress={next ? (next.amount / fees.total) * 100 : 0} value={next ? inr(next.amount) : "₹0"} sub={next ? `Due ${next.due}` : "All clear"} tone="amber" icon={<CalendarClock size={20} />} />
      </div>
      <div className="pp-grid pp-g-3-2">
        <Card title="Installment schedule" sub="Pay each pending installment one by one">
          <div className="pp-tl">{list.map((i, n) => {
            const isNext = next?.name === i.name;
            return (
              <div key={i.name} className="pp-tl-item">
                <div className={`pp-tl-dot ${i.status === "Paid" ? "pp-tone-green" : isNext ? "pp-tone-amber" : "pp-tone-gray"}`}>{i.status === "Paid" ? <Check size={16} /> : n + 1}</div>
                <div className={`pp-tl-card ${isNext ? "pp-tl-due" : ""}`}>
                  <div className="pp-item-main"><p className="pp-item-title">{i.name} <Badge tone={tone(i.status)}>{i.status}</Badge></p><p className="pp-item-sub">{i.status === "Paid" ? `Paid on ${i.due} • ${i.invoice}` : `Due by ${i.due} • Pending`}</p></div>
                  <div className="pp-item-end"><span className="pp-amount">{inr(i.amount)}</span>
                    {i.status === "Paid" ? <button className="pp-btn pp-btn-sm" onClick={() => receipt(i)}><Download size={14} />Receipt</button> : <button className="pp-btn pp-btn-sm pp-btn-primary" onClick={() => setPay(one(i))}>Pay {inr(i.amount)}</button>}</div>
                </div>
              </div>
            );
          })}</div>
        </Card>
        <div className="pp-stack">
          <Card title="Payment summary">
            <Progress value={(paid / fees.total) * 100} color="pp-bar-green" />
            <p className="pp-card-sub" style={{ margin: "8px 0 14px" }}>{Math.round((paid / fees.total) * 100)}% of the fee is paid</p>
            <div className="pp-list" style={{ marginBottom: 14 }}>
              <div className="pp-item"><span>Paid so far</span><b style={{ color: "var(--pp-green)" }}>{inr(paid)}</b></div>
              <div className="pp-item"><span>Pending ({pending.length} installments)</span><b style={{ color: "var(--pp-red)" }}>{inr(balance)}</b></div>
            </div>
            {next ? <button className="pp-btn pp-btn-primary pp-btn-block" onClick={() => setPay(one(next))}>Pay next installment {inr(next.amount)}</button> : <Badge tone="green">All fees cleared</Badge>}
            {pending.length > 1 && <button className="pp-btn pp-btn-block" style={{ marginTop: 8 }} onClick={() => setPay({ label: "All pending installments", amount: balance, names: pending.map((p) => p.name) })}>Pay all pending {inr(balance)}</button>}
          </Card>
          <Card title="Accepted payment methods">
            <div className="pp-list pp-fill">{paymentMethods.map((m) => (
              <div key={m.id} className="pp-item" style={{ padding: 10 }}><div className="pp-row-start"><span className="pp-stat-icon pp-tone-blue" style={{ width: 34, height: 34, borderRadius: 10 }}>{micon[m.id]}</span><div className="pp-item-main"><p className="pp-item-title">{m.name}</p><p className="pp-item-sub">{m.hint}</p></div></div></div>
            ))}</div>
          </Card>
        </div>
      </div>

      {pay && (
        <Modal title={`Pay ${inr(pay.amount)}`} onClose={() => !busy && setPay(null)}>
          <p className="pp-card-sub" style={{ marginBottom: 12 }}>{pay.label}</p>
          <div className="pp-methods">{paymentMethods.map((m) => (
            <label key={m.id} className={`pp-method ${method === m.id ? "pp-method-on" : ""}`}>
              <input type="radio" name="pp-method" checked={method === m.id} onChange={() => setMethod(m.id)} /><div><b>{m.name}</b><span>{m.hint}</span></div>
            </label>
          ))}</div>
          <div style={{ margin: "14px 0" }}>
            {method === "upi" && <div className="pp-field"><label>UPI ID</label><input className="pp-input" value={upi} onChange={(e) => setUpi(e.target.value)} placeholder="name@okhdfcbank" /></div>}
            {method === "card" && <><div className="pp-field"><label>Card number</label><input className="pp-input" placeholder="1234 5678 9012 3456" /></div><div className="pp-grid pp-g2"><div className="pp-field"><label>Expiry</label><input className="pp-input" placeholder="MM/YY" /></div><div className="pp-field"><label>CVV</label><input className="pp-input" type="password" placeholder="•••" /></div></div></>}
            {method === "netbanking" && <div className="pp-field"><label>Select bank</label><select className="pp-input">{["SBI", "HDFC Bank", "ICICI Bank", "Axis Bank", "Indian Bank"].map((b) => <option key={b}>{b}</option>)}</select></div>}
            {method === "emi" && <div className="pp-field"><label>EMI tenure</label><select className="pp-input" value={tenure} onChange={(e) => setTenure(e.target.value)}><option value="3">3 months</option><option value="6">6 months</option></select><span className="pp-card-sub">{inr(Math.round(pay.amount / Number(tenure)))} per month</span></div>}
            {method === "bank" && <div className="pp-field"><label>UTR number (after paying by NEFT / IMPS)</label><input className="pp-input" placeholder="Enter UTR number" /></div>}
          </div>
          <button className="pp-btn pp-btn-primary pp-btn-block" disabled={busy} onClick={confirm}>{busy ? "Processing…" : `Pay ${inr(pay.amount)}`}</button>
        </Modal>
      )}
    </>
  );
}
