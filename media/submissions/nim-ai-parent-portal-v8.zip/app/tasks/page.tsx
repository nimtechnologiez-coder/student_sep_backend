"use client";
import { useState } from "react";
import { ClipboardList, CheckCircle2, Clock, AlertTriangle } from "lucide-react";
import { Card, PageHead, Stat, Badge, Progress, Tabs, Modal } from "@/components/ui";
import { useApp } from "@/components/Providers";
import { tasks, type Task } from "@/lib/data";

const tone = (s: string) => (s === "Submitted" ? "green" : s === "Pending" ? "amber" : "gray") as "green" | "amber" | "gray";

export default function Tasks() {
  const { toast } = useApp();
  const [tab, setTab] = useState("All");
  const [sel, setSel] = useState<Task | null>(null);
  const done = tasks.filter((t) => t.status === "Submitted").length;
  const pending = tasks.filter((t) => t.status === "Pending");
  const list = tasks.filter((t) => tab === "All" || t.status === tab);
  const p = (done / tasks.length) * 360;
  const types = ["Lab", "Assignment", "Test", "Career"] as const;
  return (
    <>
      <PageHead icon={<ClipboardList size={26} />} title="Tasks" sub="Labs, assignments, tests and career tasks given to your child, with due dates and submission status." />
      <div className="pp-grid pp-g4 pp-keep2">
        <Stat label="Total tasks" progress={100} value={String(tasks.length)} sub="Since program start" tone="blue" icon={<ClipboardList size={20} />} />
        <Stat label="Submitted" progress={(done / tasks.length) * 100} value={String(done)} sub={`${Math.round((done / tasks.length) * 100)}% completed`} tone="green" icon={<CheckCircle2 size={20} />} />
        <Stat label="Pending" progress={(pending.length / tasks.length) * 100} value={String(pending.length)} sub="Due this month" tone="amber" icon={<Clock size={20} />} />
        <Stat label="Overdue" progress={0} value="0" sub="Zero late submissions" tone="red" icon={<AlertTriangle size={20} />} />
      </div>
      <div className="pp-grid pp-g-2-1">
        <Card title="All tasks" action={<Tabs items={["All", "Pending", "Submitted", "Upcoming"]} value={tab} onChange={setTab} />}>
          <div className="pp-list">{list.map((t) => (
            <div key={t.id} className="pp-item">
              <div className="pp-item-main"><p className="pp-item-title">{t.name}</p><p className="pp-item-sub">{t.type} • Month {t.month} • Due {t.due}</p></div>
              <div className="pp-item-end"><Badge tone={tone(t.status)}>{t.status}</Badge><button className="pp-btn pp-btn-sm" onClick={() => setSel(t)}>Details</button></div>
            </div>
          ))}</div>
        </Card>
        <div className="pp-stack">
          <Card title="Completion">
            <div className="pp-flex">
              <div className="pp-donut" style={{ background: `conic-gradient(var(--pp-green) 0 ${p}deg,var(--pp-amber) ${p}deg 360deg)`, width: 120, height: 120 }}><div className="pp-donut-in" style={{ width: 84, height: 84, fontSize: 18 }}><div>{done}/{tasks.length}<small>submitted</small></div></div></div>
              <div className="pp-legend"><div><span>Submitted</span><b>{done}</b></div><div><span>Pending</span><b>{pending.length}</b></div></div>
            </div>
          </Card>
          <Card title="Nearest deadlines">
            <div className="pp-list pp-fill">{pending.map((t) => <div key={t.id} className="pp-item"><div className="pp-item-main"><p className="pp-item-title">{t.name}</p><p className="pp-item-sub">Due {t.due}</p></div></div>)}</div>
          </Card>
          <Card title="By task type">
            <div className="pp-list pp-fill" style={{ justifyContent: "space-around" }}>{types.map((ty) => {
              const all = tasks.filter((t) => t.type === ty), d = all.filter((t) => t.status === "Submitted").length;
              return <div key={ty}><div className="pp-item-sub" style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><b>{ty}</b><span>{d}/{all.length}</span></div><Progress value={(d / all.length) * 100} color="pp-bar-green" /></div>;
            })}</div>
          </Card>
        </div>
      </div>
      {sel && (
        <Modal title={sel.name} onClose={() => setSel(null)}>
          <p style={{ marginBottom: 14 }}>{sel.desc}</p>
          <div className="pp-kv" style={{ marginBottom: 14 }}><div><small>Type</small><b>{sel.type}</b></div><div><small>Month</small><b>Month {sel.month}</b></div><div><small>Due date</small><b>{sel.due}</b></div><div><small>Status</small><b>{sel.status}</b></div></div>
          {sel.status !== "Submitted" && <button className="pp-btn pp-btn-primary pp-btn-block" onClick={() => { toast("Reminder sent to the student"); setSel(null); }}>Remind my child</button>}
        </Modal>
      )}
    </>
  );
}
