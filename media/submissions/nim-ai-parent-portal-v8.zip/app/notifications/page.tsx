"use client";
import { useState } from "react";
import { Bell, BellRing, CalendarDays, CreditCard, BookOpen, Download } from "lucide-react";
import { Card, PageHead, Stat, Badge, Progress, Tabs, Toggle } from "@/components/ui";
import { useApp } from "@/components/Providers";
import { download, attendance, tasks, student } from "@/lib/data";

const icon = { Fees: <CreditCard size={18} />, Academic: <BookOpen size={18} />, Events: <CalendarDays size={18} /> };
const tone = { Fees: "amber", Academic: "blue", Events: "green" } as const;

export default function Notifications() {
  const { notes, markRead, markAll, toast } = useApp();
  const [tab, setTab] = useState("All");
  const [pref, setPref] = useState({ fee: true, absent: true, task: true, event: false, sms: true });
  const unread = notes.filter((n) => n.unread).length;
  const list = notes.filter((n) => (tab === "All" ? true : tab === "Unread" ? n.unread : n.type === tab));
  const att = Math.round((attendance.present / attendance.total) * 100);
  const comp = Math.round((tasks.filter((t) => t.status === "Submitted").length / tasks.length) * 100);
  const rows: [keyof typeof pref, string][] = [["fee", "Fee reminders"], ["absent", "Absence alerts"], ["task", "New task alerts"], ["event", "Events & masterclasses"], ["sms", "Also send SMS"]];
  return (
    <>
      <PageHead icon={<Bell size={26} />} title="Notifications" sub="Fee reminders, attendance alerts, tasks and academy announcements in one place."><button className="pp-btn" onClick={() => { markAll(); toast("All notifications marked as read"); }}>Mark all as read</button></PageHead>
      <div className="pp-grid pp-g3">
        <Stat label="Unread" value={String(unread)} sub="Need your attention" tone="red" icon={<BellRing size={20} />} />
        <Stat label="Total" value={String(notes.length)} sub="In the last 30 days" tone="blue" icon={<Bell size={20} />} />
        <Stat label="Upcoming events" value={String(notes.filter((n) => n.type === "Events").length)} sub="Masterclass, Gateway 2, review" tone="green" icon={<CalendarDays size={20} />} />
      </div>
      <div className="pp-grid pp-g-2-1">
        <Card title="Inbox" action={<Tabs items={["All", "Unread", "Fees", "Academic", "Events"]} value={tab} onChange={setTab} />}>
          {list.length === 0 && <p className="pp-empty">Nothing here. You are all caught up.</p>}
          <div className="pp-list">{list.map((n) => (
            <button key={n.id} onClick={() => markRead(n.id)} className="pp-item" style={{ textAlign: "left", width: "100%", background: n.unread ? "var(--pp-pri-soft)" : undefined }}>
              <div className="pp-row-start"><div className={`pp-stat-icon pp-tone-${tone[n.type]}`} style={{ width: 40, height: 40 }}>{icon[n.type]}</div>
                <div className="pp-item-main"><p className="pp-item-title">{n.title}</p><p className="pp-item-sub">{n.body}</p></div></div>
              <div className="pp-item-end"><span className="pp-item-sub">{n.time}</span>{n.unread && <Badge tone="blue">New</Badge>}</div>
            </button>
          ))}</div>
        </Card>
        <div className="pp-stack">
          <Card title="Monthly progress report" sub={`${student.name} • auto-generated`}>
            <div className="pp-list" style={{ marginBottom: 14 }}>
              {[["Attendance", att], ["Assignment completion", comp], ["Project progress", 70]].map(([n, v]) => (
                <div key={n as string}><div className="pp-item-sub" style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}><b>{n}</b><span>{v}%</span></div><Progress value={v as number} color="pp-bar-green" /></div>
              ))}
            </div>
            <button className="pp-btn pp-btn-block" onClick={() => { download("september-progress-report.txt", `Monthly progress report: ${student.name}\nAttendance: ${att}%\nAssignment completion: ${comp}%\nProject progress: 70%`); toast("Report downloaded"); }}><Download size={16} />Download report</button>
          </Card>
          <Card title="Alert preferences">
            <div className="pp-list pp-fill">{rows.map(([k, t]) => (
              <div key={k} className="pp-item" style={{ padding: 10 }}><span>{t}</span><Toggle on={pref[k]} onChange={(v) => { setPref({ ...pref, [k]: v }); toast(`${t} ${v ? "on" : "off"}`); }} /></div>
            ))}</div>
          </Card>
        </div>
      </div>
    </>
  );
}
