"use client";
import { useState } from "react";
import { CalendarCheck, CheckCircle2, XCircle, Clock, BookOpen } from "lucide-react";
import { Card, PageHead, Stat, Progress, Badge } from "@/components/ui";
import { attendance as a, sessions, dayLabel } from "@/lib/data";

const tone = (s: string) => (s === "present" ? "green" : s === "absent" ? "red" : s === "late" ? "amber" : "blue") as "green" | "red" | "amber" | "blue";
const word = (s: string) => (s === "scheduled" ? "Scheduled" : s[0].toUpperCase() + s.slice(1));

export default function AttendancePage() {
  const [day, setDay] = useState(24);
  const pct = Math.round((a.present / a.total) * 100);
  const p = (a.present / a.total) * 360, l = p + (a.late / a.total) * 360;
  const cells: (number | null)[] = [null, ...Array.from({ length: 30 }, (_, i) => i + 1)];
  const bySession = (d: number) => sessions.find((s) => s.day === d);
  const cur = bySession(day);
  return (
    <>
      <PageHead icon={<CalendarCheck size={26} />} title="Attendance" sub="Tap any date to see that day's class, timing, trainer and attendance status. Minimum 85% is required for placement." />
      <div className="pp-grid pp-g4 pp-keep2">
        <Stat label="Total classes" progress={72} value={String(a.total)} sub="Program so far" tone="blue" icon={<BookOpen size={20} />} />
        <Stat label="Present" progress={pct} value={String(a.present)} sub={`${pct}% attendance`} tone="green" icon={<CheckCircle2 size={20} />} />
        <Stat label="Absent" progress={(a.absent / a.total) * 100} value={String(a.absent)} sub="Recording on request" tone="red" icon={<XCircle size={20} />} />
        <Stat label="Late" progress={(a.late / a.total) * 100} value={String(a.late)} sub="Joined after start" tone="amber" icon={<Clock size={20} />} />
      </div>
      <div className="pp-grid pp-g2">
        <Card title="September 2026" sub="Green present • Amber late • Red absent • Blue scheduled">
          <div className="pp-cal pp-fill" style={{ alignContent: "space-between" }}>
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => <div key={d} className="pp-cal-h">{d}</div>)}
            {cells.map((d, i) => {
              if (d === null) return <div key={i} className="pp-cal-d pp-cal-empty" />;
              const s = bySession(d);
              return <button key={i} onClick={() => setDay(d)} className={`pp-cal-d ${s ? `pp-cal-${s.status}` : ""} ${d === 24 ? "pp-cal-today" : ""} ${d === day ? "pp-cal-sel" : ""}`}>{d}</button>;
            })}
          </div>
        </Card>
        <div className="pp-stack">
          <Card title="Selected day" action={cur && <Badge tone={tone(cur.status)}>{word(cur.status)}</Badge>}>
            <p className="pp-day-big">{dayLabel(day)}</p>
            {cur ? (
              <>
                <p style={{ fontWeight: 700, fontSize: 16, margin: "8px 0 12px" }}>{cur.topic}</p>
                <div className="pp-kv"><div><small>Time</small><b>{cur.time}</b></div><div><small>Trainer</small><b>{cur.trainer}</b></div><div><small>Mode</small><b>Live online</b></div></div>
                <p className="pp-card-sub" style={{ marginTop: 12 }}>{cur.note}</p>
              </>
            ) : <p className="pp-card-sub" style={{ marginTop: 10 }}>No live class on this date (weekend, holiday or self-study day).</p>}
          </Card>
          <Card title="Overall attendance" action={<Badge tone={pct >= a.minimum ? "green" : "red"}>{pct >= a.minimum ? "Good standing" : "Below minimum"}</Badge>}>
            <div className="pp-flex">
              <div className="pp-donut" style={{ background: `conic-gradient(var(--pp-green) 0 ${p}deg,var(--pp-amber) ${p}deg ${l}deg,var(--pp-red) ${l}deg 360deg)`, width: 120, height: 120 }}>
                <div className="pp-donut-in" style={{ width: 84, height: 84, fontSize: 18 }}><div>{pct}%<small>attended</small></div></div>
              </div>
              <div className="pp-legend"><div><span>Present</span><b>{a.present}</b></div><div><span>Late</span><b>{a.late}</b></div><div><span>Absent</span><b>{a.absent}</b></div></div>
            </div>
            <p className="pp-card-sub" style={{ margin: "12px 0 6px" }}>Minimum required: {a.minimum}%</p><Progress value={pct} color="pp-bar-green" />
          </Card>
        </div>
      </div>
      <div className="pp-grid pp-g2">
        <Card title="Weekly trend" sub="Last 8 weeks"><div className="pp-bars pp-fill" style={{ minHeight: 220 }}>{a.trend.map((v, i) => <div key={i} className="pp-bar-col">{v}%<div className="pp-bar" style={{ height: `${v}%` }} />W{i + 1}</div>)}</div></Card>
        <Card title="Absent & late record" sub="Contact the academy for medical or leave letters">
          <div className="pp-list pp-fill">{a.record.map((r) => (
            <div key={r.date + r.topic} className="pp-item"><div className="pp-item-main"><p className="pp-item-title">{r.topic}</p><p className="pp-item-sub">{r.date}</p></div><Badge tone={r.tone}>{r.tag}</Badge></div>
          ))}</div>
        </Card>
      </div>
    </>
  );
}
