"use client";
import { useState } from "react";
import Link from "next/link";
import { CalendarCheck, TrendingUp, ClipboardList, Wallet, CreditCard, BookOpen, Video, Bell } from "lucide-react";
import { Card, Stat, Progress, Badge, Modal } from "@/components/ui";
import { useApp } from "@/components/Providers";
import { parent, student, fees, attendance, tasks, sessions, months, career, gateways, dayLabel, inr, type Month } from "@/lib/data";

const mTone = (s: string) => (s === "Completed" ? "green" : s === "In Progress" ? "blue" : "gray") as "green" | "blue" | "gray";

export default function Dashboard() {
  const { notes } = useApp();
  const [sel, setSel] = useState<Month | null>(null);
  const [liveOpen, setLiveOpen] = useState(false);
  const studentInClass = true; // TODO: get from your API (is the student in the live class now)
  const paid = fees.installments.filter((i) => i.status === "Paid").reduce((s, i) => s + i.amount, 0);
  const balance = fees.total - paid;
  const pct = Math.round((attendance.present / attendance.total) * 100);
  const pending = tasks.filter((t) => t.status === "Pending");
  const next = sessions.find((x) => x.status === "scheduled")!;
  const todo = tasks.filter((t) => t.status !== "Submitted").slice(0, 4);
  return (
    <>
      <div className="pp-banner">
        <div className="pp-banner-main">
          <div className="pp-banner-icon"><span style={{ fontSize: 26 }}>👋</span></div>
          <div>
            <p className="pp-banner-crumb">{student.batch} • Term 2</p>
            <h1>Welcome, {parent.name}</h1>
            <p className="pp-banner-sub">Viewing progress of <b>{student.name}</b> ({student.id})</p>
            <div className="pp-banner-chips"><span>{student.program}</span><span>Month {student.month} • Week {student.week}</span><span>Attendance {pct}%</span></div>
          </div>
        </div>
        <div className="pp-banner-actions">
          <Link href="/fees" className="pp-btn pp-btn-primary"><CreditCard size={16} />Pay fees</Link>
          <Link href="/syllabus" className="pp-btn"><BookOpen size={16} />View syllabus</Link>
        </div>
      </div>

      <div className="pp-grid pp-g4">
        <Stat label="Attendance" progress={pct} value={`${pct}%`} sub={`${attendance.present}/${attendance.total} classes • Min ${attendance.minimum}%`} tone="green" icon={<CalendarCheck size={20} />} />
        <Stat label="Course progress" progress={student.progress} value={`${student.progress}%`} sub={`Month ${student.month} of 6 • Week ${student.week}`} tone="blue" icon={<TrendingUp size={20} />} />
        <Stat label="Pending tasks" progress={(tasks.filter((t) => t.status === "Submitted").length / tasks.length) * 100} value={String(pending.length)} sub="Labs and assignments to submit" tone="amber" icon={<ClipboardList size={20} />} />
        <Stat label="Fee balance" progress={(paid / fees.total) * 100} value={inr(balance)} sub={`Paid ${inr(paid)} of ${inr(fees.total)}`} tone="red" icon={<Wallet size={20} />} />
      </div>

      <div className="pp-grid pp-g-2-1">
        <Card title="Next live class" sub="Your child's upcoming session" action={<Badge tone="green">{dayLabel(next.day)}</Badge>}>
          <h3 style={{ fontSize: 20, fontWeight: 700, color: "var(--pp-head)" }}>{next.topic}</h3>
          <p className="pp-card-sub" style={{ margin: "6px 0 16px" }}>Month 4 • {next.time} • Trainer: {next.trainer}</p>
          <div className="pp-kv pp-fill" style={{ marginBottom: 16 }}>
            <div><small>Mode</small><b>Live online (Google Meet)</b></div>
            <div><small>Lab this month</small><b>Fine-Tuning BERT for Sentiment & NER</b></div>
            <div><small>Next evaluation</small><b>Gateway 2 • 15 Oct 2026</b></div>
          </div>
          <div><button className="pp-btn pp-btn-primary" onClick={() => setLiveOpen(true)}><Video size={16} />View live class</button></div>
        </Card>
        <Card title="Quick actions">
          <div className="pp-quick">
            <Link href="/syllabus"><BookOpen size={20} />Syllabus</Link>
            <Link href="/attendance"><CalendarCheck size={20} />Attendance</Link>
            <Link href="/fees"><CreditCard size={20} />Fees</Link>
            <Link href="/notifications"><Bell size={20} />Notifications</Link>
          </div>
        </Card>
      </div>

      <Card title="6-month roadmap" sub="Click any month to see what is taught" action={<Link href="/syllabus" className="pp-link">Full syllabus</Link>}>
        <div className="pp-roadmap">{months.map((m) => (
          <button key={m.m} onClick={() => setSel(m)} className={`pp-road ${m.status === "Completed" ? "pp-road-done" : m.status === "In Progress" ? "pp-road-now" : ""}`}>
            <small>Month {m.m}</small><b>{m.title}</b><span className="pp-card-sub">{m.status === "Upcoming" ? "Upcoming" : `${m.pct}% done`}</span>
            <Progress value={m.pct} color={m.pct === 100 ? "pp-bar-green" : ""} />
          </button>
        ))}</div>
      </Card>

      <div className="pp-grid pp-g3">
        <Card title="Tasks to complete" action={<Link href="/tasks" className="pp-link">All tasks</Link>}>
          <div className="pp-list pp-fill">{todo.map((t) => (
            <div key={t.id} className="pp-item"><div className="pp-item-main"><p className="pp-item-title">{t.name}</p><p className="pp-item-sub">Due {t.due}</p></div><Badge tone={t.status === "Pending" ? "amber" : "gray"}>{t.status}</Badge></div>
          ))}</div>
        </Card>
        <Card title="Fee status" action={<Link href="/fees" className="pp-link">Pay now</Link>}>
          <Progress value={(paid / fees.total) * 100} color="pp-bar-green" />
          <p className="pp-card-sub" style={{ margin: "8px 0 14px" }}>{Math.round((paid / fees.total) * 100)}% of fee paid</p>
          <div className="pp-list pp-fill">
            <div className="pp-item"><span>Program fee</span><b>{inr(fees.total)}</b></div>
            <div className="pp-item"><span>Paid</span><b style={{ color: "var(--pp-green)" }}>{inr(paid)}</b></div>
            <div className="pp-item"><span>Balance • due 15 Oct 2026</span><b style={{ color: "var(--pp-red)" }}>{inr(balance)}</b></div>
          </div>
        </Card>
        <Card title="Career readiness" sub={career.role} action={<Link href="/placement" className="pp-link">Details</Link>}>
          <Progress value={career.ready} color="pp-bar-green" />
          <p className="pp-card-sub" style={{ margin: "8px 0 14px" }}>{career.ready}% prepared</p>
          <div className="pp-list pp-fill">{career.items.map((c) => (
            <div key={c.n} className="pp-item"><span>{c.n}</span><Badge tone={c.ok ? "green" : "amber"}>{c.v}</Badge></div>
          ))}</div>
        </Card>
      </div>

      <div className="pp-grid pp-g2">
        <Card title="Gateway evaluations" sub="Three checkpoints to track readiness">
          <div className="pp-list pp-fill">{gateways.map((g) => (
            <div key={g.n} className="pp-item"><div className="pp-item-main"><p className="pp-item-title">{g.title}</p><p className="pp-item-sub">{g.focus} • {g.note}</p></div><Badge tone={g.status === "Cleared" ? "green" : "blue"}>{g.status}</Badge></div>
          ))}</div>
        </Card>
        <Card title="Latest notifications" action={<Link href="/notifications" className="pp-link">View all</Link>}>
          <div className="pp-list pp-fill">{notes.slice(0, 3).map((n) => (
            <div key={n.id} className="pp-item"><div className="pp-item-main"><p className="pp-item-title">{n.title}</p><p className="pp-item-sub">{n.body}</p></div>{n.unread && <Badge tone="blue">New</Badge>}</div>
          ))}</div>
        </Card>
      </div>

      {liveOpen && (
        <Modal title="Live class status" onClose={() => setLiveOpen(false)}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 14 }}>
            <span className={studentInClass ? "pp-live-dot" : "pp-live-dot pp-live-off"} />
            <b style={{ fontSize: 16 }}>{studentInClass ? `${student.name} is in the live class right now` : `${student.name} has not joined the class yet`}</b>
          </div>
          <div className="pp-kv" style={{ marginBottom: 14 }}>
            <div><small>Class</small><b>{next.topic}</b></div><div><small>Time</small><b>{next.time}</b></div>
            <div><small>Trainer</small><b>{next.trainer}</b></div><div><small>Status</small><b>{studentInClass ? "Attending" : "Not joined"}</b></div>
          </div>
          <p className="pp-card-sub">Attendance is marked automatically from the live class.</p>
        </Modal>
      )}
      {sel && (
        <Modal title={`Month ${sel.m}: ${sel.title}`} onClose={() => setSel(null)}>
          <div style={{ display: "flex", gap: 8, marginBottom: 12, flexWrap: "wrap" }}><Badge tone={mTone(sel.status)}>{sel.status}</Badge><Badge tone="gray">{sel.weeks}</Badge>{sel.gateway && <Badge tone="amber">{sel.gateway}</Badge>}</div>
          <p style={{ marginBottom: 12 }}><b>Goal:</b> {sel.goal}</p>
          <div className="pp-list">{sel.topics.map((t) => <div key={t.k} className="pp-item" style={{ padding: 10 }}><div className="pp-item-main"><p className="pp-item-title">{t.k}</p><p className="pp-item-sub">{t.v}</p></div></div>)}</div>
          <div className="pp-item" style={{ marginTop: 10, background: "var(--pp-green-soft)", borderColor: "transparent" }}><div><p className="pp-item-sub">Lab project</p><p className="pp-item-title">{sel.lab}</p></div></div>
          <Progress value={sel.pct} color={sel.pct === 100 ? "pp-bar-green" : ""} />
          <Link href="/syllabus" className="pp-btn pp-btn-primary pp-btn-block" style={{ marginTop: 14 }}><Video size={16} />Open full syllabus</Link>
        </Modal>
      )}
    </>
  );
}
