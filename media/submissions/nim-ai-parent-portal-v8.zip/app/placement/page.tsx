"use client";
import { useState } from "react";
import { Briefcase, Check, X, Target, ShieldCheck, Activity, Award } from "lucide-react";
import { Card, PageHead, Stat, Progress, Badge, Modal } from "@/components/ui";
import { career, gateways, attendance } from "@/lib/data";

type Detail = { title: string; tag?: string; tone?: "green" | "blue" | "amber" | "gray"; text: string; rows?: [string, string][] };
const reqInfo = [
  "Every live class is tracked on the portal. Minimum 85% attendance and regular assignment submission are needed for the placement pipeline.",
  "Gateway 1 (after Month 2), Gateway 2 (after Month 4) and Gateway 3 (final phase, industry capstone) must all be completed.",
  "The production-grade capstone is built in Month 6. The GitHub portfolio needs a clear repo structure, README, demos and deployment links.",
  "Mentors review the role-based resume and the LinkedIn profile (headline, About section, project showcase) and approve them.",
  "A technical mock interview (AI/ML/GenAI fundamentals, coding, project deep-dives) and an HR round are completed, with feedback.",
  "The academic team runs a final placement readiness review before the student enters the employer pipeline.",
];

export default function Placement() {
  const [d, setD] = useState<Detail | null>(null);
  const req = career.requirements.filter((r) => r.ok).length;
  const att = Math.round((attendance.present / attendance.total) * 100);
  return (
    <>
      <PageHead icon={<Briefcase size={26} />} title="Career & Placement" sub="How your child is preparing for a job. Tap any card to see more details." />
      <div className="pp-grid pp-g4 pp-keep2">
        <Stat label="Career readiness" progress={career.ready} value={`${career.ready}%`} sub={career.role} tone="green" icon={<Target size={20} />} />
        <Stat label="Gateways cleared" progress={33} value="1 of 3" sub="Gateway 2 on 15 Oct" tone="blue" icon={<ShieldCheck size={20} />} />
        <Stat label="Attendance discipline" progress={att} value={`${att}%`} sub="Minimum 85% required" tone="amber" icon={<Activity size={20} />} />
        <Stat label="AI-900 certification" value="In prep" sub="Microsoft Azure AI Fundamentals" tone="red" icon={<Award size={20} />} />
      </div>
      <Card title="Placement journey" sub="Starts in Month 3 alongside the technical track">
        <div className="pp-steps">{career.journey.map((j) => (
          <button key={j.m} onClick={() => setD({ title: `${j.m}: ${j.t}`, tag: j.s === "done" ? "Completed" : j.s === "now" ? "Current phase" : "Upcoming", tone: j.s === "done" ? "green" : j.s === "now" ? "blue" : "gray", text: j.v })} className={`pp-step ${j.s === "done" ? "pp-step-done" : j.s === "now" ? "pp-step-now" : ""}`}>
            <small>{j.m}{j.s === "now" ? " • CURRENT" : ""}</small><b>{j.t}</b><p>{j.v}</p>
          </button>
        ))}</div>
      </Card>
      <div className="pp-grid pp-g2">
        <Card title="Placement requirements" sub={`${req} of ${career.requirements.length} checkpoints cleared`}>
          <Progress value={(req / career.requirements.length) * 100} color="pp-bar-green" />
          <div className="pp-list pp-fill" style={{ marginTop: 14 }}>{career.requirements.map((r, i) => (
            <button key={r.t} className="pp-check" onClick={() => setD({ title: r.t, tag: r.ok ? "Done" : "Pending", tone: r.ok ? "green" : "amber", text: reqInfo[i], rows: i === 1 ? gateways.map((g) => [g.title, g.status] as [string, string]) : undefined })}>
              <span className={`pp-check-icon ${r.ok ? "pp-tone-green" : "pp-tone-gray"}`}>{r.ok ? <Check size={14} /> : <X size={14} />}</span><span style={{ flex: 1 }}>{r.t}</span><Badge tone={r.ok ? "green" : "gray"}>{r.ok ? "Done" : "Pending"}</Badge>
            </button>
          ))}</div>
        </Card>
        <Card title="Gateway evaluations" sub="Three-gateway framework">
          <div className="pp-list pp-fill">{gateways.map((g) => (
            <button key={g.n} className="pp-item" onClick={() => setD({ title: `${g.title} • ${g.focus}`, tag: g.status, tone: g.status === "Cleared" ? "green" : "blue", text: g.covers, rows: [["Status", g.status], ["Details", g.note]] })}>
              <div className="pp-item-main"><p className="pp-item-title">{g.title} • {g.focus}</p><p className="pp-item-sub">{g.covers}</p></div><Badge tone={g.status === "Cleared" ? "green" : "blue"}>{g.status}</Badge>
            </button>
          ))}</div>
        </Card>
      </div>
      <Card title="Career & placement support" sub="What the academy does to get your child job-ready">
        <div className="pp-tiles">{career.support.map((c) => (
          <button key={c.t} className="pp-tile pp-tile-col" onClick={() => setD({ title: c.t, tag: c.s, tone: "blue", text: c.v })}><b>{c.t}</b><span>{c.s}</span></button>
        ))}</div>
      </Card>
      <Card title="Hiring network & company tie-ups" sub="50+ students placed across 170+ partner companies">
        <div className="pp-tiles">{career.companies.map((c) => (
          <button key={c} className={`pp-tile ${c === "NIM Technologies" ? "pp-tile-hi" : ""}`} onClick={() => setD({ title: c, tag: "Hiring partner", tone: "green", text: "Part of the NIM Academy placement network that hires freshers from engineering and technology streams. Interview opportunities are offered to eligible students. Placement is not guaranteed and depends on student performance and employer requirements." })}>{c}</button>
        ))}</div>
        <p className="pp-card-sub" style={{ marginTop: 14 }}>Company names shown are part of the placement network. Placement is not guaranteed and depends on student performance and employer requirements.</p>
      </Card>
      {d && (
        <Modal title={d.title} onClose={() => setD(null)}>
          {d.tag && <div style={{ marginBottom: 12 }}><Badge tone={d.tone ?? "gray"}>{d.tag}</Badge></div>}
          <p style={{ marginBottom: 14 }}>{d.text}</p>
          {d.rows && <div className="pp-list">{d.rows.map(([k, v]) => <div key={k} className="pp-item"><span className="pp-item-sub">{k}</span><b>{v}</b></div>)}</div>}
        </Modal>
      )}
    </>
  );
}
