"use client";
import { useState } from "react";
import { BookOpen, Download, Clock, MonitorPlay, Users, ShieldCheck, FlaskConical } from "lucide-react";
import { Card, PageHead, Stat, Badge, Progress } from "@/components/ui";
import { useApp } from "@/components/Providers";
import { months, stack, highlights, download } from "@/lib/data";

const tone = (s: string) => (s === "Completed" ? "green" : s === "In Progress" ? "blue" : "gray") as "green" | "blue" | "gray";
const split = (v: string) => v.split(",").map((x) => x.trim()).filter(Boolean);

export default function Syllabus() {
  const { toast } = useApp();
  const [idx, setIdx] = useState(3);
  const m = months[idx];
  const overall = Math.round(months.reduce((s, x) => s + x.pct, 0) / months.length);
  const skills = m.topics.flatMap((t) => split(t.v));
  const exportTxt = () => {
    download("nim-ai-syllabus.txt", months.map((x) => `Month ${x.m}: ${x.title} (${x.weeks})\nGoal: ${x.goal}\n` + x.topics.map((t) => `  - ${t.k}: ${t.v}`).join("\n") + `\n  Lab: ${x.lab}` + (x.gateway ? `\n  ${x.gateway}` : "")).join("\n\n"));
    toast("Syllabus downloaded");
  };
  return (
    <>
      <PageHead icon={<BookOpen size={26} />} title="Syllabus" sub="Generative AI Engineering Program: what your child learns each month, the labs they build and the evaluations they clear."><button className="pp-btn" onClick={exportTxt}><Download size={16} />Download syllabus</button></PageHead>
      <div className="pp-grid pp-g4 pp-keep2">
        <Stat label="Duration" progress={overall} value="6 Months" sub={`${overall}% completed`} tone="blue" icon={<Clock size={20} />} />
        <Stat label="Format" progress={100} value="Live" sub="Online & hybrid batches" tone="green" icon={<MonitorPlay size={20} />} />
        <Stat label="Batch size" value="10–15" sub="Small cohort mentoring" tone="amber" icon={<Users size={20} />} />
        <Stat label="Evaluations" progress={33} value="3 Gateways" sub="After Month 2, 4 and 6" tone="red" icon={<ShieldCheck size={20} />} />
      </div>
      <div className="pp-mstrip">{months.map((x, i) => (
        <button key={x.m} onClick={() => setIdx(i)} className={`pp-mbtn ${i === idx ? "pp-mbtn-on" : ""}`}>
          <div className="pp-mtop"><span className="pp-mnum">{x.m}</span><Badge tone={tone(x.status)}>{x.status}</Badge></div>
          <div><b>{x.title}</b><small style={{ display: "block", marginTop: 2 }}>{x.weeks}</small></div>
          <Progress value={x.pct} color={x.pct === 100 ? "pp-bar-green" : ""} />
        </button>
      ))}</div>

      <div className="pp-grid pp-g-3-2">
        <Card title={`Month ${m.m}: ${m.title}`} sub={m.goal} action={<Badge tone={tone(m.status)}>{m.status}</Badge>}>
          <Progress value={m.pct} color={m.pct === 100 ? "pp-bar-green" : ""} />
          <p className="pp-card-sub" style={{ margin: "8px 0 14px" }}>{m.pct}% of this month completed</p>
          <div className="pp-list pp-fill">{m.topics.map((t) => (
            <div key={t.k} className="pp-item pp-topic" style={{ alignItems: "flex-start" }}>
              <p className="pp-item-title">{t.k}</p>
              <div className="pp-chips" style={{ marginTop: 0 }}>{split(t.v).map((c) => <span key={c} className="pp-tag">{c}</span>)}</div>
            </div>
          ))}</div>
        </Card>
        <div className="pp-stack">
          <Card title="Month summary">
            <div className="pp-kv">
              <div><small>Duration</small><b>{m.weeks}</b></div><div><small>Focus areas</small><b>{m.topics.length} topic groups</b></div>
              <div><small>Evaluation</small><b>{m.gateway ?? "Assignments & labs"}</b></div><div><small>Status</small><b>{m.status}</b></div>
            </div>
          </Card>
          <Card title="Hands-on lab" action={<FlaskConical size={18} color="var(--pp-pri)" />}>
            <p style={{ fontSize: 16, fontWeight: 600, color: "var(--pp-head)" }}>{m.lab}</p>
            <p className="pp-card-sub" style={{ marginTop: 6 }}>A real project that proves the month's skills and goes into the GitHub portfolio.</p>
          </Card>
          <Card title="Skills covered this month">
            <div className="pp-chips" style={{ marginTop: 0 }}>{skills.map((s) => <span key={s} className="pp-tag">{s}</span>)}</div>
          </Card>
        </div>
      </div>
      <Card title="Tools & tech stack mastered" sub="Used across the 6 months">
        <div className="pp-tiles">{stack.map((s) => <div key={s.t} className="pp-tile pp-tile-col"><b>{s.t}</b><span>{s.v}</span></div>)}</div>
      </Card>
      <div className="pp-grid pp-g2">
        <Card title="Key program highlights"><div className="pp-list pp-fill">{highlights.map((h) => (
          <div key={h.t} className="pp-item"><div className="pp-item-main"><p className="pp-item-title">{h.t}</p><p className="pp-item-sub">{h.v}</p></div></div>
        ))}</div></Card>
        <Card title="Microsoft Azure AI Fundamentals (AI-900)" sub="Certification included in the program">
          <p className="pp-card-sub" style={{ marginBottom: 14 }}>Learners are prepared for and guided through this globally recognized Microsoft credential that validates foundational AI and machine learning knowledge.</p>
          <div className="pp-list pp-fill">{["Globally recognized Microsoft credential", "Strengthens resume, LinkedIn & portfolio", "Included as part of the program"].map((t) => (
            <div key={t} className="pp-item"><span>✅ {t}</span></div>
          ))}</div>
        </Card>
      </div>
    </>
  );
}
