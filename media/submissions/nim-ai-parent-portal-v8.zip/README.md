# NIM AI Parent Portal (Next.js + TypeScript)

npm install
npm run dev  -> http://localhost:3000

Dummy data: lib/data.ts (syllabus, fees and placement follow the NIM AI Career Academy brochure).
All CSS classes use the pp- prefix (app/globals.css). Light/dark via data-theme on <html>.
